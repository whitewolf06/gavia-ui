Legato Sans
Install the TTF files to use Legato Sans on your computer.
For the web, load legato.css and set font-family: "Legato Sans Core", "Legato Sans", sans-serif.
Gavia Sans and Gavia are also registered by this stylesheet. Keep the WOFF2 and CSS files together.
Font software is licensed under the SIL Open Font License 1.1. Retain both OFL files.
